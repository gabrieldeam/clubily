// app/not-found.tsx
export default function NotFound() {
  return (
    <div className="flex h-screen items-center justify-center">
      <h1 className="text-4xl font-bold">Página não encontrada</h1>
    </div>
  )
}
