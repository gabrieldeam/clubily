// src/components/PointsRulesMain/PointsRuleModal/PointsRuleModal.tsx
'use client';

import { FormEvent, useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { RuleType } from '@/types/points';
import type { PointsRuleRead, PointsRuleCreate } from '@/types/points';
import type { BranchRead } from '@/types/branch';
import type { ProductCategoryRead } from '@/types/productCategory';
import type { InventoryItemRead } from '@/types/inventoryItem';
import FloatingLabelInput from '@/components/FloatingLabelInput/FloatingLabelInput';
import Button from '@/components/Button/Button';
import { getRuleTypeLabel } from '@/utils/roleUtils';
import { listBranches } from '@/services/branchService';
import { listProductCategories } from '@/services/productCategoryService';
import { listInventoryItems } from '@/services/inventoryItemService';
import styles from './PointsRuleModal.module.css';

/** Campos possíveis dentro de `config` — e assinatura de índice para flexibilidade */
interface RuleConfig extends Record<string, unknown> {
  step?: number;
  points?: number;
  event_name?: string;
  window_days?: number;
  threshold?: number;
  threshold_per_period?: number;
  consecutive_periods?: number;
  period_days?: number;
  bonus_points?: number;
  cooldown_days?: number;
  categories?: string[];
  item_ids?: string[];
  branch_id?: string;
  multiplier?: number;
  events?: Record<string, unknown>;
  date?: string;
  start?: string;
  end?: string;
}

interface Props {
  rule: PointsRuleRead | null;
  onSave: (data: PointsRuleCreate, id?: string) => void;
  onCancel: () => void;
}

export default function PointsRuleModal({ rule, onSave, onCancel }: Props) {
  const router = useRouter();
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [ruleType, setRuleType] = useState<RuleType>(RuleType.value_spent);
  const hiddenRuleTypes = [RuleType.event, RuleType.digital_behavior];
  const [config, setConfig] = useState<RuleConfig>({});
  const [active, setActive] = useState(true);
  const [visible, setVisible] = useState(true);

  const [branches, setBranches] = useState<BranchRead[]>([]);
  const [categories, setCategories] = useState<ProductCategoryRead[]>([]);
  const [items, setItems] = useState<InventoryItemRead[]>([]);

  const catLimit = 10;
  const [catSkip, setCatSkip] = useState(0);
  const [catTotal, setCatTotal] = useState(0);
  const itemLimit = 10;
  const [itemSkip, setItemSkip] = useState(0);
  const [itemTotal, setItemTotal] = useState(0);

  useEffect(() => {
    listProductCategories(catSkip, catLimit).then(res => {
      setCategories(res.data.items);
      setCatTotal(res.data.total);
    });
  }, [catSkip]);

  useEffect(() => {
    listInventoryItems(itemSkip, itemLimit).then(res => {
      setItems(res.data.items);
      setItemTotal(res.data.total);
    });
  }, [itemSkip]);

  useEffect(() => {
    listBranches().then(res => setBranches(res.data));
  }, []);

  useEffect(() => {
    if (rule) {
      setName(rule.name);
      setDescription(rule.description ?? '');
      setRuleType(rule.rule_type);
      setConfig(rule.config ?? {});
      setActive(rule.active);
      setVisible(rule.visible);
    } else {
      setName('');
      setDescription('');
      setRuleType(RuleType.value_spent);
      setConfig({});
      setActive(true);
      setVisible(true);
    }
  }, [rule]);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    const payload: PointsRuleCreate = { name, description, rule_type: ruleType, config, active, visible };
    onSave(payload, rule?.id);
  };

  const num = (v: unknown) => (typeof v === 'number' ? v : '');
  const str = (v: unknown) => (typeof v === 'string' ? v : '');

  const renderConfigFields = () => {
    switch (ruleType) {
      case RuleType.value_spent:
        return (
          <>
            <FloatingLabelInput label="R$ por passo" type="number" value={num(config.step)} onChange={e => setConfig({ ...config, step: Number(e.target.value) })} />
            <FloatingLabelInput label="Pontos por passo" type="number" value={num(config.points)} onChange={e => setConfig({ ...config, points: Number(e.target.value) })} />
          </>
        );

      case RuleType.event:
        return (
          <>
            <FloatingLabelInput label="Nome do evento" type="text" value={str(config.event_name)} onChange={e => setConfig({ ...config, event_name: e.target.value })} />
            <FloatingLabelInput label="Pontos" type="number" value={num(config.points)} onChange={e => setConfig({ ...config, points: Number(e.target.value) })} />
          </>
        );

      case RuleType.category:
        if (!categories.length) {
          return <div className={styles.field}><Button onClick={() => router.push('/register?section=categories')}>Cadastrar categoria</Button></div>;
        }
        return (
          <div className={styles.field}>
            <label>Categorias</label>
            <select multiple size={Math.min(categories.length, 10)} className={styles.multiSelect} value={(config.categories ?? []) as string[]} onChange={() => {}}>
              {categories.map(cat => (
                <option key={cat.id} value={cat.id} onMouseDown={e => { e.preventDefault(); const curr = (config.categories ?? []) as string[]; const next = curr.includes(cat.id) ? curr.filter(id => id !== cat.id) : [...curr, cat.id]; setConfig({ ...config, categories: next }); }}>
                  {cat.name}
                </option>
              ))}
            </select>
            <div className={styles.paginationControls}>
              <button type="button" disabled={!catSkip} onClick={() => setCatSkip(catSkip - catLimit)}>Anterior</button>
              <span>Página {Math.floor(catSkip / catLimit) + 1} de {Math.ceil(catTotal / catLimit)}</span>
              <button type="button" disabled={catSkip + catLimit >= catTotal} onClick={() => setCatSkip(catSkip + catLimit)}>Próxima</button>
            </div>
            <div className={styles.selectedText}>{(config.categories ?? []).map(id => categories.find(c => c.id === id)?.name).filter(Boolean).join(', ') || 'Nenhuma selecionada'}</div>
            <FloatingLabelInput label="Multiplicador" type="number" value={num(config.multiplier)} onChange={e => setConfig({ ...config, multiplier: Number(e.target.value) })} />
          </div>
        );

      case RuleType.inventory:
        if (!items.length) {
          return <div className={styles.field}><Button onClick={() => router.push('/register?section=inventory')}>Cadastrar item de inventário</Button></div>;
        }
        return (
          <div className={styles.field}>
            <label>Itens de Inventário</label>
            <select multiple size={Math.min(items.length, 10)} className={styles.multiSelect} value={(config.item_ids ?? []) as string[]} onChange={() => {}}>
              {items.map(it => (
                <option key={it.id} value={it.id} onMouseDown={e => { e.preventDefault(); const curr = (config.item_ids ?? []) as string[]; const next = curr.includes(it.id) ? curr.filter(id => id !== it.id) : [...curr, it.id]; setConfig({ ...config, item_ids: next }); }}>
                  {it.name}
                </option>
              ))}
            </select>
            <div className={styles.paginationControls}>
              <button type="button" disabled={!itemSkip} onClick={() => setItemSkip(itemSkip - itemLimit)}>Anterior</button>
              <span>Página {Math.floor(itemSkip / itemLimit) + 1} de {Math.ceil(itemTotal / itemLimit)}</span>
              <button type="button" disabled={itemSkip + itemLimit >= itemTotal} onClick={() => setItemSkip(itemSkip + itemLimit)}>Próxima</button>
            </div>
            <div className={styles.selectedText}>{(config.item_ids ?? []).map(id => items.find(i => i.id === id)?.name).filter(Boolean).join(', ') || 'Nenhum selecionado'}</div>
            <FloatingLabelInput label="Multiplicador" type="number" value={num(config.multiplier)} onChange={e => setConfig({ ...config, multiplier: Number(e.target.value) })} />
          </div>
        );

      case RuleType.geolocation:
        if (!branches.length) {
          return <div className={styles.field}><Button onClick={() => router.push('/register')}>Cadastrar filial</Button></div>;
        }
        return (
          <div className={styles.field}>
            <label>Filial</label>
            <select className={styles.select} value={str(config.branch_id)} onChange={e => setConfig({ ...config, branch_id: e.target.value })}>
              <option value="">Nenhuma selecionada</option>
              {branches.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
            </select>
            <FloatingLabelInput label="Pontos" type="number" value={num(config.points)} onChange={e => setConfig({ ...config, points: Number(e.target.value) })} />
          </div>
        );

      default:
        return <p>Configuração não implementada para este tipo.</p>;
    }
  };

  return (
    <div className={styles.modalContent}>
      <h2>{rule ? 'Editar Regra' : 'Nova Regra'}</h2>
      <FloatingLabelInput label="Nome" type="text" value={name} onChange={e => setName(e.target.value)} />
      <div className={styles.field}><label>Descrição</label><textarea value={description} onChange={e => setDescription(e.target.value)} className={styles.textarea} /></div>
      <div className={styles.field}><label>Tipo de Regra</label><select value={ruleType} onChange={e => setRuleType(e.target.value as RuleType)} className={styles.select}>{Object.values(RuleType).filter(rt => !hiddenRuleTypes.includes(rt)).map(rt => <option key={rt} value={rt}>{getRuleTypeLabel(rt)}</option>)}</select></div>
      <div className={styles.configSection}><h3>Configuração</h3>{renderConfigFields()}</div>
      <div className={styles.switches}><label><input type="checkbox" checked={active} onChange={e => setActive(e.target.checked)} /> Ativa</label><label><input type="checkbox" checked={visible} onChange={e => setVisible(e.target.checked)} /> Visível</label></div>
      <div className={styles.actions}><Button onClick={handleSubmit}>Salvar</Button><Button onClick={onCancel} bgColor="#f3f4f6" style={{ color: '#374151' }}>Cancelar</Button></div>
    </div>
  );
}
